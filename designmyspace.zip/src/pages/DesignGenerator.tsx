import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Sparkles, Palette, Wallet, Check, Loader2, Download, ShoppingBag, ImageIcon, Eye, EyeOff, Heart, Lock, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/src/lib/utils';
import { GoogleGenAI } from "@google/genai";
import { useAuth, handleFirestoreError, OperationType } from '../context/AuthContext';
import { db, doc, updateDoc, increment, collection, addDoc } from '../firebase';
import { useNavigate } from 'react-router-dom';

const SYSTEM_PROMPT = `You are a world-class AI Interior Designer. 
Your goal is to transform user rooms into stunning, realistic spaces while strictly preserving the original room's layout and structure.
STRICT RULES:
- Only generate interior room designs (no random images, no unrelated content)
- Keep the same room structure (walls, windows, doors, floor level)
- Output must look photorealistic, like a high-end architectural photograph
- Follow user inputs for style, mood, and budget strictly
- No people, no text, no watermarks in the output`;

export default function DesignGenerator() {
  const { user, userData, login } = useAuth();
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = React.useState(false);
  const [selectedStyle, setSelectedStyle] = React.useState<string>('Korean');
  const [roomType, setRoomType] = React.useState<string>('Living Room');
  const [colorTheme, setColorTheme] = React.useState<string>('Neutral');
  const [lighting, setLighting] = React.useState<string>('Natural');
  const [selectedMood, setSelectedMood] = React.useState<string>('Cozy');
  const [budget, setBudget] = React.useState<string>('Medium');
  const [uploadedImage, setUploadedImage] = React.useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = React.useState<string | null>(null);
  const [showBefore, setShowBefore] = React.useState(false);
  const [explanation, setExplanation] = React.useState<string>('');
  const [furnitureList, setFurnitureList] = React.useState<string[]>([]);
  const [isSaved, setIsSaved] = React.useState(false);

  const isLimitReached = 
    ((userData?.plan === 'basic' || (userData?.plan as string) === 'free') && (userData?.designsUsed || 0) >= 5) ||
    (userData?.plan === 'starter' && (userData?.designsUsed || 0) >= 25);

  const styles = [
    { id: 'Korean', name: 'Korean', icon: '🌸' },
    { id: 'Minimalist', name: 'Minimal', icon: '🧊' },
    { id: 'Luxury', name: 'Luxury', icon: '💎' },
    { id: 'Modern', name: 'Modern', icon: '🏡' },
    { id: 'Gaming', name: 'Gaming', icon: '🎮' },
    { id: 'Boho', name: 'Boho', icon: '🌿' },
    { id: 'Scandinavian', name: 'Scandi', icon: '🪵' },
    { id: 'Industrial', name: 'Industrial', icon: '🧱' },
    { id: 'Dark', name: 'Dark', icon: '🌑' },
  ];

  const roomTypes = [
    { id: 'Bedroom', icon: '🛏️' },
    { id: 'Living Room', icon: '🛋️' },
    { id: 'Study Room', icon: '📚' },
    { id: 'Office', icon: '💻' },
    { id: 'Kitchen', icon: '🍳' },
  ];

  const colorThemes = [
    { id: 'Light', icon: '🤍' },
    { id: 'Warm', icon: '🌤️' },
    { id: 'Dark', icon: '🌑' },
    { id: 'Pastel', icon: '🌸' },
    { id: 'Neutral', icon: '🪶' },
  ];

  const lightingStyles = [
    { id: 'Natural', icon: '☀️' },
    { id: 'Warm', icon: '💡' },
    { id: 'LED', icon: '✨' },
    { id: 'Soft', icon: '🌙' },
    { id: 'Bright', icon: '🔆' },
  ];

  const moods = [
    { id: 'Calm', icon: '😌' },
    { id: 'Cozy', icon: '☕' },
    { id: 'Productive', icon: '📚' },
    { id: 'Aesthetic', icon: '✨' },
    { id: 'Luxury', icon: '💎' },
  ];

  const budgets = [
    { id: 'Low', label: 'Low ₹' },
    { id: 'Medium', label: 'Medium ₹₹' },
    { id: 'High', label: 'High ₹₹₹' },
  ];

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
        setGeneratedImage(null);
        setIsSaved(false);
        toast.success('Image uploaded successfully!');
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSave = () => {
    try {
      // 1. Get existing designs or empty array
      let saved = JSON.parse(localStorage.getItem("designs") || "[]");
      
      // 2. Safety check: ensure it's an array
      if (!Array.isArray(saved)) {
        saved = [];
      }

      // 3. Construct design data using the "guaranteed fix" logic
      const designData = {
        id: Date.now(),
        image: (document.getElementById("generatedImage") as HTMLImageElement)?.src || "",
        style: selectedStyle || "",
        room: roomType || "",
        mood: selectedMood || "",
        date: new Date().toLocaleString(),
        explanation: explanation,
        furniture: furnitureList
      };

      // 4. Validate image (using the ID-based check as requested)
      if (!designData.image || designData.image.includes('placeholder')) {
        toast.error("No design to save ❌");
        return;
      }

      // 5. Add to array
      saved.push(designData);

      // 6. Save back to localStorage
      localStorage.setItem("designs", JSON.stringify(saved));

      // 7. Update Firestore as well for persistence
      if (user) {
        addDoc(collection(db, 'users', user.uid, 'designs'), {
          ...designData,
          createdAt: new Date().toISOString(),
          title: `${selectedStyle} ${selectedMood} Room`,
        }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/designs`));
      }

      setIsSaved(true);
      toast.success("Design saved successfully ❤️", {
        description: "View it in your saved collection",
        action: {
          label: 'View Saved',
          onClick: () => navigate('/saved')
        }
      });

    } catch (error) {
      console.error("Save error:", error);
      toast.error("Failed to save ❌");
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = `designmyspace-${selectedStyle.toLowerCase()}.png`;
    link.click();
    toast.success('Download started!');
  };

  const generateDesign = async () => {
    if (!user) {
      toast.error('Please login to generate designs.');
      login();
      return;
    }

    if (isLimitReached) {
      toast.error('Free limit reached!', {
        description: 'Upgrade to Pro for unlimited designs.',
        action: {
          label: 'Upgrade Now',
          onClick: () => navigate('/pricing')
        }
      });
      return;
    }

    if (!uploadedImage) return;
    setIsGenerating(true);
    setIsSaved(false);
    
    const loadingToast = toast.loading('AI is analyzing your space...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const imagePrompt = `
        Professional interior redesign of the provided room.
        ROOM TYPE: ${roomType}
        STYLE: ${selectedStyle}
        MOOD: ${selectedMood}
        COLOR THEME: ${colorTheme}
        LIGHTING: ${lighting}
        BUDGET: ${budget}
        
        REQUIREMENTS:
        - Maintain the exact architectural structure (walls, windows, doors).
        - Replace all furniture and decor with high-end ${selectedStyle} pieces.
        - Use a ${selectedMood} lighting scheme with ${lighting} style.
        - Follow the ${colorTheme} color theme strictly.
        - Ensure the result looks like a professional architectural photograph.
        - Resolution: 4K, photorealistic, highly detailed textures.
        - No people, no text, no watermarks.
      `;
      const base64Data = uploadedImage.split(',')[1];
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType: "image/png" } },
            { text: imagePrompt }
          ]
        },
        config: { systemInstruction: SYSTEM_PROMPT }
      });

      let newImageUrl = null;
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          newImageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      toast.loading('Generating design details...', { id: loadingToast });

      const textResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Redesign explanation for ${selectedStyle} ${roomType}, ${budget} budget, ${selectedMood} mood, ${colorTheme} theme, ${lighting} lighting. JSON: {explanation: string, furniture: string[]}`,
        config: { responseMimeType: "application/json" }
      });

      const data = JSON.parse(textResponse.text || '{}');
      
      // Increment design count in Firestore
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          designsUsed: increment(1)
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
      }

      setGeneratedImage(newImageUrl || `https://picsum.photos/seed/result-${Date.now()}/1000/1000`);
      setExplanation(data.explanation || 'Design generated successfully.');
      setFurnitureList(data.furniture || ["Minimalist Desk", "Warm LED Strip", "Linen Curtains", "Jute Rug"]);
      
      toast.success('Your dream space is ready!', { id: loadingToast });
    } catch (error) {
      console.error(error);
      setGeneratedImage(`https://picsum.photos/seed/fallback-${Date.now()}/1000/1000`);
      setExplanation('We encountered an issue with the AI, but here is a fallback design for inspiration.');
      setFurnitureList(["Aesthetic Lamp", "Soft Throw", "Wall Art", "Indoor Plant"]);
      toast.error('AI generation failed. Showing fallback design.', { id: loadingToast });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* LEFT PANEL: INPUT */}
        <div className="lg:col-span-5 space-y-10">
          {/* Design Limit Info */}
          {user && userData?.plan === 'free' && (
            <div className="bg-slate-900 text-white p-6 rounded-[2rem] shadow-xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#c8a27a]/20 blur-3xl rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
              <div className="relative z-10">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#c8a27a]">Free Plan Usage</span>
                  <span className="text-xs font-bold">{userData.designsUsed} / 5 Designs</span>
                </div>
                <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mb-4">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(userData.designsUsed / 5) * 100}%` }}
                    className="h-full bg-[#c8a27a]"
                  />
                </div>
                <button 
                  onClick={() => navigate('/pricing')}
                  className="text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 hover:text-[#c8a27a] transition-colors"
                >
                  Upgrade to Pro for unlimited designs <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* 1. Image Upload */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">1. Upload Your Space</label>
            <div className="relative group">
              <input
                type="file"
                accept="image/*"
                onChange={handleUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
              <div className={cn(
                "aspect-[4/3] rounded-[2.5rem] border-2 border-dashed flex flex-col items-center justify-center gap-4 transition-all duration-500",
                uploadedImage ? "border-transparent bg-slate-50" : "border-slate-200 hover:border-[#c8a27a] hover:bg-beige-50/30"
              )}>
                {uploadedImage ? (
                  <div className="relative w-full h-full rounded-[2.5rem] overflow-hidden shadow-soft">
                    <img src={uploadedImage} alt="Original" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="px-4 py-2 bg-white/90 backdrop-blur-md rounded-full text-xs font-bold shadow-lg">Change Image</div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="w-16 h-16 bg-beige-100 rounded-full flex items-center justify-center text-[#c8a27a] group-hover:scale-110 transition-transform duration-500">
                      <Upload className="w-8 h-8" />
                    </div>
                    <div className="text-center">
                      <p className="font-serif text-lg">Drop your photo here</p>
                      <p className="text-xs text-slate-400 mt-1">PNG, JPG or WEBP (max 5MB)</p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* 2. Selection Grid */}
          <div className="space-y-8">
            {/* Style Selection */}
            <div className="space-y-4">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">2. Choose Style</label>
              <div className="grid grid-cols-3 gap-3">
                {styles.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={cn(
                      "p-4 rounded-2xl border text-center transition-all duration-300",
                      selectedStyle === style.id 
                        ? "border-slate-900 bg-slate-900 text-white shadow-lg scale-[1.02]" 
                        : "border-slate-100 bg-white hover:border-slate-200"
                    )}
                  >
                    <div className="text-xl mb-1">{style.icon}</div>
                    <div className="text-[10px] font-bold uppercase tracking-tighter">{style.name}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Room Type */}
            <div className="space-y-4">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">3. Room Type</label>
              <div className="flex flex-wrap gap-2">
                {roomTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setRoomType(type.id)}
                    className={cn(
                      "px-4 py-2 rounded-full border text-xs font-bold transition-all",
                      roomType === type.id 
                        ? "border-slate-900 bg-slate-900 text-white" 
                        : "border-slate-100 bg-white hover:border-slate-200"
                    )}
                  >
                    {type.icon} {type.id}
                  </button>
                ))}
              </div>
            </div>

            {/* Budget */}
            <div className="space-y-4">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">4. Budget Level</label>
              <div className="grid grid-cols-3 gap-3">
                {budgets.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setBudget(b.id)}
                    className={cn(
                      "p-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all",
                      budget === b.id 
                        ? "border-slate-900 bg-slate-900 text-white" 
                        : "border-slate-100 bg-white hover:border-slate-200"
                    )}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={generateDesign}
            disabled={isGenerating || !uploadedImage || isLimitReached}
            className={cn(
              "w-full py-6 rounded-[2rem] font-bold uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-3 transition-all duration-500 shadow-xl",
              isGenerating || !uploadedImage || isLimitReached
                ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                : "bg-slate-900 text-white hover:bg-slate-800 hover:-translate-y-1 active:scale-95"
            )}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Designing...
              </>
            ) : isLimitReached ? (
              <>
                <Lock className="w-5 h-5" />
                Limit Reached
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Your Dream Design
              </>
            )}
          </button>
        </div>

        {/* RIGHT PANEL: OUTPUT */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            {generatedImage ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <div className="relative aspect-[4/3] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white group">
                  <img id="generatedImage" src={generatedImage} alt="Generated Design" className="w-full h-full object-cover" />
                  
                  {/* Before/After Toggle */}
                  <button
                    onMouseDown={() => setShowBefore(true)}
                    onMouseUp={() => setShowBefore(false)}
                    onMouseLeave={() => setShowBefore(false)}
                    onTouchStart={() => setShowBefore(true)}
                    onTouchEnd={() => setShowBefore(false)}
                    className="absolute bottom-6 left-6 px-4 py-2 bg-white/90 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg flex items-center gap-2 hover:bg-white transition-colors z-20"
                  >
                    {showBefore ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    Hold to View Before
                  </button>

                  <AnimatePresence>
                    {showBefore && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 z-10"
                      >
                        <img src={uploadedImage!} alt="Before" className="w-full h-full object-cover" />
                        <div className="absolute top-6 left-6 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-widest">Original Space</div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Action Buttons */}
                  <div className="absolute top-6 right-6 flex flex-col gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button 
                      onClick={handleSave}
                      className={cn(
                        "p-4 rounded-full backdrop-blur-md shadow-lg transition-all hover:scale-110",
                        isSaved ? "bg-[#c8a27a] text-white" : "bg-white/90 text-slate-900 hover:bg-white"
                      )}
                    >
                      <Heart className={cn("w-5 h-5", isSaved && "fill-current")} />
                    </button>
                    <button 
                      onClick={handleDownload}
                      className="p-4 bg-white/90 backdrop-blur-md text-slate-900 rounded-full shadow-lg hover:bg-white transition-all hover:scale-110"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100">
                    <h3 className="font-serif text-2xl mb-4 flex items-center gap-2">
                      <Palette className="w-6 h-6 text-[#c8a27a]" /> Design Concept
                    </h3>
                    <p className="text-slate-500 text-sm leading-relaxed">{explanation}</p>
                  </div>
                  <div className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100">
                    <h3 className="font-serif text-2xl mb-4 flex items-center gap-2">
                      <ShoppingBag className="w-6 h-6 text-[#c8a27a]" /> Furniture & Decor
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {furnitureList.map((item, i) => (
                        <span key={i} className="px-3 py-1 bg-beige-50 text-slate-700 rounded-full text-[10px] font-bold uppercase tracking-wider border border-beige-100">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full min-h-[600px] rounded-[3rem] border-4 border-dashed border-slate-100 flex flex-col items-center justify-center text-center p-12 bg-slate-50/50"
              >
                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-soft mb-8">
                  <ImageIcon className="w-10 h-10 text-slate-200" />
                </div>
                <h3 className="text-3xl font-serif mb-4">Your design will appear here</h3>
                <p className="text-slate-400 max-w-sm mx-auto">Upload a photo and choose your preferences to see the AI magic happen.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
