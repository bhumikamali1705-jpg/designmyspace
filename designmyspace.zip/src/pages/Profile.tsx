import React from 'react';
import { motion } from 'motion/react';
import { User, Settings, Bell, Shield, LogOut, Crown, Grid, Heart, Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { cn } from '../lib/utils';

export default function Profile() {
  const { user, userData, logout } = useAuth();

  const stats = [
    { 
      label: 'Designs Used', 
      value: `${userData?.designsUsed || 0} / ${
        userData?.plan === 'basic' ? '5' : 
        userData?.plan === 'starter' ? '25' : 
        '∞'
      }`, 
      icon: Sparkles 
    },
    { label: 'Current Plan', value: userData?.plan ? userData.plan.charAt(0).toUpperCase() + userData.plan.slice(1) : 'Basic', icon: Crown },
    { label: 'Member Since', value: userData?.createdAt ? new Date(userData.createdAt).toLocaleDateString() : 'N/A', icon: Grid },
  ];

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <div className="w-20 h-20 bg-beige-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <User className="w-10 h-10 text-slate-300" />
        </div>
        <h2 className="text-2xl font-serif mb-2">Please log in</h2>
        <p className="text-slate-500 mb-8">You need to be logged in to view your profile.</p>
        <Link to="/" className="bg-slate-900 text-white px-8 py-3 rounded-full font-bold">
          Go Home
        </Link>
      </div>
    );
  }

  const isPremium = userData?.plan === 'pro' || userData?.plan === 'elite';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative"
        >
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-white shadow-2xl bg-beige-100 flex items-center justify-center">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <User className="w-16 h-16 text-slate-300" />
            )}
          </div>
          {isPremium && (
            <div className="absolute bottom-2 right-2 p-2 bg-[#c8a27a] rounded-full text-white shadow-lg">
              <Crown className="w-4 h-4" />
            </div>
          )}
        </motion.div>

        <div className="text-center md:text-left flex-grow">
          <div className="flex flex-col md:flex-row items-center gap-4 mb-2">
            <h1 className="text-3xl md:text-4xl font-serif">{user.displayName}</h1>
            <span className={cn(
              "px-3 py-1 text-[10px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1",
              isPremium ? "bg-[#c8a27a]/10 text-[#c8a27a]" : "bg-slate-100 text-slate-500"
            )}>
              {userData?.plan ? userData.plan.toUpperCase() : 'BASIC'} PLAN
            </span>
          </div>
          <p className="text-slate-500 mb-6 max-w-lg">{user.email}</p>
          
          <div className="flex justify-center md:justify-start gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center md:text-left">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                  <stat.icon className="w-3 h-3" /> {stat.label}
                </div>
                <div className="text-xl font-serif font-bold text-slate-800">{stat.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100">
            <h2 className="text-xl font-serif mb-8 flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#c8a27a]" /> Account Details
            </h2>
            
            <div className="space-y-6">
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Full Name</label>
                <div className="text-lg font-medium text-slate-800">{user.displayName}</div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Email Address</label>
                <div className="text-lg font-medium text-slate-800">{user.email}</div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Current Subscription</label>
                <div className="flex items-center gap-3">
                  <div className="text-lg font-medium text-slate-800 capitalize">{userData?.plan || 'Basic'}</div>
                  <Link to="/pricing" className="text-xs font-bold text-[#c8a27a] hover:underline underline-offset-4">Change Plan</Link>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Usage Status</label>
                <div className="text-lg font-medium text-slate-800">
                  {userData?.designsUsed || 0} / {
                    userData?.plan === 'basic' ? '5' : 
                    userData?.plan === 'starter' ? '25' : 
                    'Unlimited'
                  } Designs
                </div>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-slate-50 flex flex-col sm:flex-row gap-4">
              <Link to="/pricing" className="flex-grow py-4 bg-slate-900 text-white rounded-2xl font-bold text-center hover:bg-slate-800 transition-colors">
                Upgrade Plan
              </Link>
              <button 
                onClick={logout}
                className="flex-grow py-4 border border-red-100 text-red-500 rounded-2xl font-bold hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
              >
                <LogOut className="w-5 h-5" /> Logout
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {!isPremium ? (
            <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#c8a27a]/20 rounded-full blur-3xl"></div>
              <div className="relative z-10">
                <Crown className="w-10 h-10 text-[#c8a27a] mb-6" />
                <h3 className="text-2xl font-serif mb-2">Go Premium ✨</h3>
                <p className="text-slate-400 text-sm mb-8 leading-relaxed">Unlock unlimited AI generations, 4K downloads, and exclusive premium interior styles.</p>
                <Link to="/pricing" className="block w-full py-4 bg-[#c8a27a] text-white rounded-2xl font-bold hover:bg-[#b8926a] transition-colors text-center shadow-lg">
                  View Plans
                </Link>
              </div>
            </div>
          ) : (
            <div className="bg-[#c8a27a] rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/20 rounded-full blur-3xl"></div>
              <div className="relative z-10">
                <Crown className="w-10 h-10 text-white mb-6" />
                <h3 className="text-2xl font-serif mb-2">{userData?.plan?.toUpperCase()} ACTIVE</h3>
                <p className="text-white/80 text-sm mb-8 leading-relaxed">You have full access to all premium features. Thank you for being a valued member!</p>
                <Link to="/pricing" className="block w-full py-4 bg-white text-[#c8a27a] rounded-2xl font-bold hover:bg-slate-50 transition-colors text-center shadow-lg">
                  Manage Plan
                </Link>
              </div>
            </div>
          )}

          <div className="bg-slate-50 rounded-[2.5rem] p-8 border border-slate-100">
            <h3 className="font-serif text-lg mb-4">Support</h3>
            <p className="text-slate-500 text-sm mb-6 leading-relaxed">Need help with your designs or account? Our team is here for you.</p>
            <a href="mailto:support@designmyspace.com" className="inline-flex items-center gap-2 text-slate-900 font-bold text-sm hover:underline underline-offset-4">
              Contact Us <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
