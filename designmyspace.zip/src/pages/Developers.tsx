import React from 'react';
import { motion } from 'motion/react';
import { User, Code, Database, Cpu, Github, Linkedin, Mail } from 'lucide-react';

const developers = [
  {
    name: "Vaibhavi Jotangiya Ghanshyambhai",
    role: "Frontend Developer & UI Designer",
    description: "Focused on creating clean, modern, and user-friendly interfaces to deliver the best user experience.",
    icon: Code,
    color: "bg-blue-50 text-blue-600"
  },
  {
    name: "Bhumika Mali Bhagwan Bhai",
    role: "Backend Developer",
    description: "Responsible for handling system logic, data management, and ensuring smooth performance.",
    icon: Database,
    color: "bg-green-50 text-green-600"
  },
  {
    name: "Bansari Kakdiya Ashvin Bhai",
    role: "AI & Integration Developer",
    description: "Worked on integrating AI features to generate smart and aesthetic interior design suggestions.",
    icon: Cpu,
    color: "bg-purple-50 text-purple-600"
  }
];

export default function Developers() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-serif mb-4">Meet the Developers 👩‍💻</h1>
        <p className="text-slate-500 max-w-lg mx-auto">
          The creative minds behind DesignMySpace. Combining design, logic, and AI to transform your home.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {developers.map((dev, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -10 }}
            className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 text-center group transition-all hover:shadow-2xl"
          >
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 transition-transform group-hover:scale-110 ${dev.color}`}>
              <dev.icon className="w-10 h-10" />
            </div>
            
            <h3 className="text-xl font-serif mb-2 text-slate-900 leading-tight">{dev.name}</h3>
            <p className="text-[10px] font-bold uppercase tracking-widest text-[#c8a27a] mb-4">{dev.role}</p>
            
            <p className="text-slate-500 text-sm leading-relaxed mb-8">
              "{dev.description}"
            </p>

            <div className="flex justify-center gap-4 pt-6 border-t border-slate-50">
              <button className="p-2 text-slate-400 hover:text-slate-900 transition-colors">
                <Github className="w-4 h-4" />
              </button>
              <button className="p-2 text-slate-400 hover:text-slate-900 transition-colors">
                <Linkedin className="w-4 h-4" />
              </button>
              <button className="p-2 text-slate-400 hover:text-slate-900 transition-colors">
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-20 bg-slate-900 rounded-[3rem] p-8 md:p-12 text-white text-center relative overflow-hidden shadow-2xl"
      >
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#c8a27a]/20 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <h2 className="text-3xl font-serif mb-4">Our Vision</h2>
          <p className="text-slate-400 max-w-2xl mx-auto leading-relaxed">
            We believe that everyone deserves a beautiful home. Our mission is to make professional interior design accessible to everyone through the power of artificial intelligence.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
