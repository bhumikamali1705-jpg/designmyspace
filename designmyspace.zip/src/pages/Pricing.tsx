import React from 'react';
import { motion } from 'motion/react';
import { Check, Sparkles, Zap, Shield, ArrowRight } from 'lucide-react';
import { useAuth } from '@/src/context/AuthContext';
import { db, doc, updateDoc } from '@/src/firebase';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export default function Pricing() {
  const { user, userData } = useAuth();
  const navigate = useNavigate();

  const payNow = async (plan: any) => {
    if (!user) {
      toast.error('Please login first to upgrade.');
      return;
    }

    if (plan.id === 'basic') {
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          plan: 'basic',
          designsUsed: 0
        });
        toast.success(`Successfully switched to Basic Plan! 🚀`);
        navigate('/design');
      } catch (error) {
        console.error(error);
        toast.error('Failed to update plan.');
      }
      return;
    }

    const options = {
      key: import.meta.env.VITE_RAZORPAY_KEY_ID || "rzp_test_your_key_id",
      amount: parseInt(plan.price.replace('₹', '')) * 100,
      currency: "INR",
      name: "DesignMySpace",
      description: `Upgrade to ${plan.name}`,
      handler: async function (response: any) {
        try {
          // 1. Update Firestore
          await updateDoc(doc(db, 'users', user.uid), {
            plan: plan.id,
            designsUsed: 0
          });

          // 2. Update localStorage as requested
          const localUser = JSON.parse(localStorage.getItem("user") || "{}");
          localUser.plan = plan.id;
          localStorage.setItem("user", JSON.stringify(localUser));

          // 3. Show success alert and toast
          alert("Payment successful");
          toast.success(`Successfully upgraded to ${plan.name}! 🚀`, {
            description: 'Your design limits have been updated.'
          });
          
          navigate('/design');
        } catch (error) {
          console.error(error);
          toast.error('Failed to update plan after payment.');
        }
      },
      prefill: {
        name: user.displayName || "",
        email: user.email || "",
      },
      theme: {
        color: "#c8a27a",
      },
    };

    const rzp = new (window as any).Razorpay(options);
    rzp.open();
  };

  const plans = [
    {
      id: 'basic',
      name: '🌱 BASIC',
      price: '₹0',
      description: 'Perfect for exploring AI interior design.',
      features: [
        '5 Design Generations',
        'Standard AI Model',
        'Basic Styles',
        'Community Support'
      ],
      buttonText: userData?.plan === 'basic' || !userData?.plan ? 'Current Plan' : 'Basic Plan',
      buttonClass: (userData?.plan === 'basic' || !userData?.plan) ? 'bg-slate-100 text-slate-400 cursor-default' : 'bg-slate-900 text-white hover:bg-slate-800',
      isCurrent: userData?.plan === 'basic' || !userData?.plan
    },
    {
      id: 'starter',
      name: '🌿 STARTER',
      price: '₹99',
      period: '/month',
      description: 'For casual home decorators.',
      features: [
        '25 Designs / month',
        'All basic styles',
        'Better quality',
        'Email Support'
      ],
      buttonText: userData?.plan === 'starter' ? 'Current Plan' : 'Upgrade',
      buttonClass: userData?.plan === 'starter' ? 'bg-slate-100 text-slate-400 cursor-default' : 'bg-slate-900 text-white hover:bg-slate-800',
      isCurrent: userData?.plan === 'starter'
    },
    {
      id: 'pro',
      name: '💎 PRO',
      price: '₹199',
      period: '/month',
      description: 'For home owners and design enthusiasts.',
      features: [
        'Unlimited Designs',
        'All styles + premium',
        'Faster generation',
        'Priority Support'
      ],
      buttonText: userData?.plan === 'pro' ? 'Current Plan' : 'Upgrade ⭐',
      buttonClass: userData?.plan === 'pro' ? 'bg-slate-100 text-slate-400 cursor-default' : 'bg-[#c8a27a] text-white hover:bg-[#b8926a]',
      isCurrent: userData?.plan === 'pro',
      popular: true
    },
    {
      id: 'elite',
      name: '👑 ELITE',
      price: '₹299',
      period: '/month',
      description: 'The ultimate design experience.',
      features: [
        'Unlimited + Priority AI',
        'Ultra HD designs',
        'Future features access',
        '24/7 VIP Support'
      ],
      buttonText: userData?.plan === 'elite' ? 'Current Plan' : 'Go Elite 🚀',
      buttonClass: userData?.plan === 'elite' ? 'bg-slate-100 text-slate-400 cursor-default' : 'bg-slate-900 text-white hover:bg-slate-800',
      isCurrent: userData?.plan === 'elite'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <div className="text-center mb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#c8a27a]/10 text-[#c8a27a] text-[10px] font-bold uppercase tracking-widest mb-6"
        >
          <Sparkles className="w-3.5 h-3.5" /> Pricing Plans
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-serif mb-6">Choose Your Plan ✨</h1>
        <p className="text-slate-500 max-w-2xl mx-auto text-lg">
          Unlock the full potential of AI-powered interior design. Transform your space without limits.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`relative p-8 rounded-[2.5rem] border-2 transition-all flex flex-col ${
              plan.popular ? 'border-[#c8a27a] bg-white shadow-2xl scale-105 z-10' : 'border-slate-100 bg-slate-50/50'
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#c8a27a] text-white px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
                Most Popular
              </div>
            )}

            <div className="mb-8">
              <h3 className="text-xl font-serif mb-2">{plan.name}</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-bold">{plan.price}</span>
                {plan.period && <span className="text-slate-400 font-medium text-sm">{plan.period}</span>}
              </div>
              <p className="text-slate-500 mt-4 text-xs leading-relaxed">{plan.description}</p>
            </div>

            <div className="space-y-4 mb-10 flex-grow">
              {plan.features.map((feature) => (
                <div key={feature} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${plan.popular ? 'bg-[#c8a27a]/10 text-[#c8a27a]' : 'bg-slate-200 text-slate-400'}`}>
                    <Check className="w-3 h-3" />
                  </div>
                  <span className="text-xs text-slate-600">{feature}</span>
                </div>
              ))}
            </div>

            <button
              onClick={!plan.isCurrent ? () => payNow(plan) : undefined}
              className={`w-full py-4 rounded-full font-bold text-xs transition-all flex items-center justify-center gap-2 ${plan.buttonClass}`}
            >
              {plan.buttonText}
              {!plan.isCurrent && <ArrowRight className="w-4 h-4" />}
            </button>
          </motion.div>
        ))}
      </div>

      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
        <div className="text-center">
          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Zap className="w-6 h-6 text-slate-900" />
          </div>
          <h4 className="font-bold mb-2">Instant Generation</h4>
          <p className="text-sm text-slate-500">Get your designs in seconds with our high-speed AI processing.</p>
        </div>
        <div className="text-center">
          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Shield className="w-6 h-6 text-slate-900" />
          </div>
          <h4 className="font-bold mb-2">Secure Storage</h4>
          <p className="text-sm text-slate-500">All your designs are securely saved in your private collection.</p>
        </div>
        <div className="text-center">
          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-6 h-6 text-slate-900" />
          </div>
          <h4 className="font-bold mb-2">Premium Quality</h4>
          <p className="text-sm text-slate-500">Photorealistic 4K renders that look like professional photography.</p>
        </div>
      </div>
    </div>
  );
}
