import React from 'react';
import { motion } from 'motion/react';
import { HelpCircle, ChevronDown, BookOpen, MessageSquare, Heart, Image, Zap } from 'lucide-react';

const faqs = [
  {
    q: "How do I generate a design?",
    a: "Upload your room image, select preferences (style, mood, room type), and click generate. Our AI will analyze your space and create a new design in seconds.",
    icon: Image
  },
  {
    q: "Why can’t I generate more designs?",
    a: "Free users are limited to 5 designs. To generate more, you can upgrade to our Starter, Pro, or Elite plans which offer higher limits and additional features.",
    icon: Zap
  },
  {
    q: "How do I save designs?",
    a: "Click the ❤️ Save button after generating a design. Your saved designs will be available in your 'Saved Spaces' collection for future reference.",
    icon: Heart
  },
  {
    q: "My design is not generating properly?",
    a: "Try uploading a clear, well-lit room image for better results. Avoid blurry or extremely dark photos, as the AI needs clear visual data to work effectively.",
    icon: HelpCircle
  }
];

export default function Support() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-serif mb-4">Support 🛠️</h1>
        <p className="text-slate-500 max-w-lg mx-auto">
          Need help using DesignMySpace? We're here to guide you through every step of your interior design journey.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all"
        >
          <div className="w-16 h-16 bg-beige-50 rounded-2xl flex items-center justify-center text-[#c8a27a] mb-6 group-hover:scale-110 transition-transform">
            <BookOpen className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-serif mb-2">Knowledge Base</h3>
          <p className="text-slate-500 text-sm mb-6">Explore our detailed guides and tutorials on how to get the most out of our AI tools.</p>
          <button className="px-6 py-2 bg-slate-900 text-white rounded-full text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-colors">
            Browse Guides
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all"
        >
          <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform">
            <MessageSquare className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-serif mb-2">Community Forum</h3>
          <p className="text-slate-500 text-sm mb-6">Connect with other users, share your designs, and get inspiration from our community.</p>
          <button className="px-6 py-2 border border-slate-200 text-slate-900 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-slate-50 transition-colors">
            Join Community
          </button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-beige-50 rounded-[3rem] p-8 md:p-12 border border-beige-100"
      >
        <h2 className="text-3xl font-serif mb-8 text-center">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-sm border border-beige-200 group hover:border-[#c8a27a]/30 transition-colors"
            >
              <div className="flex gap-4">
                <div className="w-10 h-10 bg-beige-50 rounded-xl flex items-center justify-center text-[#c8a27a] flex-shrink-0">
                  <faq.icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2 text-slate-900">{faq.q}</h4>
                  <p className="text-slate-500 text-sm leading-relaxed">{faq.a}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
