import { motion } from 'motion/react';
import { ArrowRight, Sparkles, ImageIcon, Palette, Zap, Shield, Heart, Upload } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const features = [
    { icon: Sparkles, title: 'AI Design', desc: 'Professional interior designs powered by state-of-the-art AI.' },
    { icon: Shield, title: 'Budget Friendly', desc: 'Get high-end design suggestions without the high-end price tag.' },
    { icon: Zap, title: 'Fast Results', desc: 'Visualize your dream room in seconds, not weeks.' },
  ];

  const steps = [
    { icon: Upload, title: 'Upload', desc: 'Take a photo of your current room.' },
    { icon: Palette, title: 'Customize', desc: 'Pick your style, mood, and budget.' },
    { icon: Sparkles, title: 'Generate', desc: 'Watch your space transform instantly.' },
  ];

  return (
    <div className="overflow-hidden bg-white">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=2000&auto=format&fit=crop"
            alt="Premium Interior"
            className="w-full h-full object-cover brightness-[0.7] scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/30" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white" />
        </div>

        <div className="relative z-10 text-center max-w-4xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-[10px] font-bold uppercase tracking-[0.2em] mb-8">
              <Sparkles className="w-3.5 h-3.5 text-[#c8a27a]" /> AI-Powered Interior Transformation
            </div>
            <h1 className="text-5xl md:text-8xl font-serif mb-8 leading-[1] text-white drop-shadow-2xl">
              Design Your <br />
              <span className="italic text-white/90">Dream Space</span> ✨
            </h1>
            <p className="text-white/90 text-lg md:text-xl max-w-xl mx-auto mb-12 font-light leading-relaxed drop-shadow-md">
              Experience the future of interior design. Transform any room instantly with our state-of-the-art AI technology.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
              <Link
                to="/design"
                className="w-full sm:w-auto group bg-[#c8a27a] text-white px-10 py-5 rounded-full font-bold text-base flex items-center justify-center gap-3 hover:bg-[#b8926a] transition-all shadow-2xl hover:scale-105 active:scale-95"
              >
                Start Designing <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/pricing"
                className="w-full sm:w-auto px-10 py-5 rounded-full font-bold text-base text-white border border-white/40 backdrop-blur-md hover:bg-white/10 transition-all flex items-center justify-center gap-2"
              >
                View Plans <Sparkles className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 px-6 md:px-12 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif mb-4">How It Works</h2>
            <p className="text-slate-500 max-w-md mx-auto">Three simple steps to visualize your perfect interior.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center text-center p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 text-[#c8a27a]">
                  <step.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-serif mb-3">{step.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 md:px-12 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-[#c8a27a]/10 rounded-full flex items-center justify-center mb-6 text-[#c8a27a]">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold mb-2 uppercase tracking-wider text-slate-800">{feature.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto bg-[#c8a27a] rounded-[3rem] p-12 md:p-20 text-center text-white shadow-2xl relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=2000&auto=format&fit=crop"
              alt="Interior"
              className="w-full h-full object-cover opacity-20"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#c8a27a]/60" />
          </div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-6xl font-serif mb-8 leading-tight">
              Ready to transform <br />
              <span className="italic opacity-90">your home?</span>
            </h2>
            <Link 
              to="/design" 
              className="inline-flex items-center gap-3 bg-white text-slate-900 px-10 py-5 rounded-full font-bold text-lg hover:bg-slate-100 transition-all transform hover:scale-105 active:scale-95 shadow-xl"
            >
              Start Designing Now <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
