import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Heart, Share2, Trash2, Download, ExternalLink, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth, handleFirestoreError, OperationType } from '../context/AuthContext';
import { db, collection, onSnapshot, query, orderBy, deleteDoc, doc } from '../firebase';

export default function Saved() {
  const { user } = useAuth();
  const [savedDesigns, setSavedDesigns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Load from localStorage first (for immediate feedback)
    const localDesigns = JSON.parse(localStorage.getItem("designs") || "[]");
    
    if (!user) {
      setSavedDesigns(localDesigns);
      setLoading(false);
      return;
    }

    // 2. Load from Firestore and merge
    const q = query(
      collection(db, 'users', user.uid, 'designs'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const firestoreDesigns = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Merge logic: prioritize firestore but keep unique local ones
      const merged = [...firestoreDesigns];
      
      localDesigns.forEach((local: any) => {
        const exists = firestoreDesigns.some((f: any) => f.image === local.image);
        if (!exists) {
          merged.push(local);
        }
      });

      setSavedDesigns(merged);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/designs`);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const deleteDesign = async (designId: string, isLocalOnly: boolean = false) => {
    if (isLocalOnly) {
      const local = JSON.parse(localStorage.getItem("designs") || "[]");
      const filtered = local.filter((d: any) => d.id.toString() !== designId.toString());
      localStorage.setItem("designs", JSON.stringify(filtered));
      setSavedDesigns(prev => prev.filter(d => d.id.toString() !== designId.toString()));
      toast.success('Local design removed.');
      return;
    }

    if (!user) return;
    
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'designs', designId));
      // Also remove from local if it exists there
      const local = JSON.parse(localStorage.getItem("designs") || "[]");
      const filtered = local.filter((d: any) => d.id.toString() !== designId.toString());
      localStorage.setItem("designs", JSON.stringify(filtered));
      
      toast.success('Design removed from your collection.');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/designs/${designId}`);
    }
  };

  const exportAll = () => {
    if (savedDesigns.length === 0) return;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(savedDesigns));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "my-designs.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
    toast.success('Designs exported as JSON!');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-10 h-10 text-slate-300 animate-spin" />
      </div>
    );
  }

  if (!user && savedDesigns.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <div className="w-20 h-20 bg-beige-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Heart className="w-10 h-10 text-slate-300" />
        </div>
        <h2 className="text-2xl font-serif mb-2">Please log in</h2>
        <p className="text-slate-500 mb-8">You need to be logged in to view your saved designs.</p>
        <Link to="/" className="px-8 py-3 bg-slate-900 text-white rounded-full font-bold">
          Go Home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
        <div>
          <h1 className="text-4xl md:text-5xl font-serif mb-2">Saved Spaces</h1>
          <p className="text-slate-500">Your collection of AI-designed dream interiors.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={exportAll}
            disabled={savedDesigns.length === 0}
            className="px-6 py-2 rounded-full border border-slate-200 text-sm font-medium hover:bg-slate-50 transition-colors disabled:opacity-50"
          >
            Export All
          </button>
          <Link to="/design" className="px-6 py-2 rounded-full bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 transition-colors">
            New Design
          </Link>
        </div>
      </div>

      {savedDesigns.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {savedDesigns.map((design, index) => (
            <motion.div
              key={design.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-3xl overflow-hidden shadow-soft border border-slate-100"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={design.image}
                  alt={design.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(design.image);
                      toast.success('Image link copied to clipboard!');
                    }}
                    className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/40 transition-colors" 
                    title="Share"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => deleteDesign(design.id, !design.createdAt)}
                    className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-red-500/40 transition-colors" 
                    title="Delete"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <div className="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-wider text-slate-800">
                  {design.style}
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-serif">{design.title}</h3>
                  <span className="text-[10px] text-slate-400 font-medium uppercase">
                    {design.createdAt ? new Date(design.createdAt).toLocaleDateString() : 'N/A'}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500 mb-6">
                  <span className="px-2 py-0.5 bg-beige-100 rounded text-xs">{design.mood}</span>
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-xs">{design.roomType}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = design.image;
                      link.download = `design-${design.id}.png`;
                      link.click();
                    }}
                    className="flex-1 py-3 flex items-center justify-center gap-2 rounded-xl border border-beige-200 text-sm font-medium hover:bg-beige-50 transition-colors"
                  >
                    <Download className="w-4 h-4" /> Download
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="py-24 text-center">
          <div className="w-20 h-20 bg-beige-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Heart className="w-10 h-10 text-slate-300" />
          </div>
          <h2 className="text-2xl font-serif mb-2">No saved designs yet</h2>
          <p className="text-slate-500 mb-8">Start designing your space to see them here.</p>
          <Link to="/design" className="btn-primary">
            Start Designing
          </Link>
        </div>
      )}
    </div>
  );
}
