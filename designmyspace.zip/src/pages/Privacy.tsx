import React from 'react';
import { motion } from 'motion/react';
import { Shield, Lock, Eye, UserCheck, FileText } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-serif mb-4">Privacy Policy 🔒</h1>
        <p className="text-slate-500 max-w-lg mx-auto">
          At DesignMySpace, we value your privacy. We're committed to protecting your personal information and ensuring a safe experience.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {[
          { icon: Shield, title: "Data Protection", text: "We only collect necessary information such as your name and email to improve your experience." },
          { icon: Lock, title: "Secure Uploads", text: "Your uploaded images are used only for generating designs and are not shared with third parties." },
          { icon: Eye, title: "No Data Misuse", text: "We do not sell or misuse your data. Your privacy is our top priority." },
          { icon: UserCheck, title: "Your Consent", text: "By using our platform, you agree to our privacy practices and data handling." }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 + index * 0.1 }}
            className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 group hover:shadow-xl transition-all"
          >
            <div className="w-12 h-12 bg-beige-50 rounded-xl flex items-center justify-center text-[#c8a27a] mb-6 group-hover:scale-110 transition-transform">
              <item.icon className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-serif mb-3">{item.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{item.text}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-slate-900 rounded-[3rem] p-8 md:p-12 text-white relative overflow-hidden shadow-2xl"
      >
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-[#c8a27a]/10 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-[#c8a27a]">
              <FileText className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-serif">Full Privacy Statement</h2>
          </div>
          <div className="space-y-6 text-slate-400 text-sm leading-relaxed">
            <p>
              At DesignMySpace, we value your privacy. We only collect necessary information such as your name and email to improve your experience.
            </p>
            <p>
              Your uploaded images are used only for generating designs and are not shared with third parties. We use advanced encryption and secure servers to ensure your data is protected at all times.
            </p>
            <p>
              We do not sell or misuse your data. Our platform is built on trust, and we maintain strict internal controls over data access.
            </p>
            <p>
              By using our platform, you agree to our privacy practices. We may update this policy from time to time, and any major changes will be communicated to our users.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
