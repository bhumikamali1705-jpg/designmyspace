import React from 'react';
import { motion } from 'motion/react';
import { Mail, MessageSquare, Send, MapPin, Phone } from 'lucide-react';
import { toast } from 'sonner';

export default function Contact() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Message sent! We will get back to you soon.');
    (e.target as HTMLFormElement).reset();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-serif mb-4">Contact Us 📩</h1>
        <p className="text-slate-500 max-w-lg mx-auto">
          Have questions, feedback, or need help? We're here to assist you in designing your perfect space.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">Name</label>
              <input
                required
                type="text"
                placeholder="Your Name"
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-[#c8a27a] transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">Email</label>
              <input
                required
                type="email"
                placeholder="your@email.com"
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-[#c8a27a] transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-2">Message</label>
              <textarea
                required
                rows={4}
                placeholder="How can we help?"
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-[#c8a27a] transition-all resize-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-lg active:scale-95"
            >
              <Send className="w-4 h-4" /> Send Message
            </button>
          </form>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-8"
        >
          <div className="bg-beige-50 rounded-[2.5rem] p-8 border border-beige-100">
            <h3 className="font-serif text-xl mb-6">Get in Touch</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#c8a27a] shadow-sm">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Email Us</p>
                  <a href="mailto:designmyspace100@gmail.com" className="text-slate-900 font-medium hover:text-[#c8a27a] transition-colors">
                    designmyspace100@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#c8a27a] shadow-sm">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Live Chat</p>
                  <p className="text-slate-900 font-medium">Available Mon-Fri, 9am-6pm</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#c8a27a]/20 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <h3 className="text-xl font-serif mb-4">Follow Our Journey</h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">
                Join our community of design enthusiasts and stay updated with the latest AI interior trends.
              </p>
              <div className="flex gap-4">
                {['Twitter', 'Instagram', 'Pinterest'].map((social) => (
                  <button key={social} className="px-4 py-2 bg-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-white/20 transition-colors">
                    {social}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
