import React from 'react';
import { motion } from 'motion/react';
import { ScrollText, CheckCircle, AlertCircle, ShieldCheck, FileCheck } from 'lucide-react';

export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-serif mb-4">Terms of Service 📜</h1>
        <p className="text-slate-500 max-w-lg mx-auto">
          By using DesignMySpace, you agree to use the platform responsibly and follow our community guidelines.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {[
          { icon: CheckCircle, title: "Responsible Use", text: "By using DesignMySpace, you agree to use the platform responsibly and follow our community guidelines." },
          { icon: AlertCircle, title: "Content Guidelines", text: "Users must not upload harmful, illegal, or inappropriate content. We maintain a safe environment for all." },
          { icon: ShieldCheck, title: "Personal Use", text: "The generated designs are for personal use and inspiration only. Commercial use requires specific licensing." },
          { icon: FileCheck, title: "Access Rights", text: "We reserve the right to limit access if misuse is detected or terms are violated." }
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 + index * 0.1 }}
            className="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 group hover:shadow-xl transition-all"
          >
            <div className="w-12 h-12 bg-beige-50 rounded-xl flex items-center justify-center text-[#c8a27a] mb-6 group-hover:scale-110 transition-transform">
              <item.icon className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-serif mb-3">{item.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{item.text}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-beige-50 rounded-[3rem] p-8 md:p-12 border border-beige-100 relative overflow-hidden shadow-sm"
      >
        <div className="absolute top-0 right-0 w-60 h-60 bg-[#c8a27a]/5 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#c8a27a] shadow-sm">
              <ScrollText className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-serif">Terms of Service</h2>
          </div>
          <div className="space-y-6 text-slate-600 text-sm leading-relaxed">
            <p>
              By using DesignMySpace, you agree to use the platform responsibly. Our tools are designed to help you visualize and create beautiful spaces, and we expect all users to respect our community standards.
            </p>
            <p>
              Users must not upload harmful, illegal, or inappropriate content. We use automated and manual systems to monitor content and ensure a safe environment for all users.
            </p>
            <p>
              The generated designs are for personal use and inspiration only. While we encourage you to share your results, the underlying AI models and platform features are protected by intellectual property laws.
            </p>
            <p>
              We reserve the right to limit access if misuse is detected. This includes but is not limited to automated scraping, attempting to bypass design limits, or any activity that compromises platform stability.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
