import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Compass, Sparkles, Heart, User, Menu, X, LogIn, LogOut, CreditCard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster } from 'sonner';
import { cn } from '@/src/lib/utils';
import { useAuth } from '../context/AuthContext';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();
  const { user, userData, login, logout } = useAuth();

  const navItems = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Design', path: '/design', icon: Sparkles },
    { name: 'Saved', path: '/saved', icon: Heart },
    { name: 'Pricing', path: '/pricing', icon: CreditCard },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Toaster position="top-center" richColors />
      {/* Desktop Navigation */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-beige-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-beige-100 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-slate-800" />
              </div>
              <span className="text-xl font-serif font-bold tracking-tight">DesignMySpace</span>
            </Link>

            <nav className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-slate-900",
                    location.pathname === item.path ? "text-slate-900" : "text-slate-500"
                  )}
                >
                  {item.name}
                </Link>
              ))}
              
              <div className="h-4 w-[1px] bg-slate-200 mx-2" />

              {user ? (
                <div className="flex items-center gap-4">
                  <Link to="/profile" className="flex items-center gap-3 group">
                    <div className="flex flex-col items-end">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-[#c8a27a]">
                        {userData?.plan === 'elite' ? 'Elite 🚀' :
                         userData?.plan === 'pro' ? 'Pro ✨' : 
                         userData?.plan === 'starter' ? 'Starter 🌿' : 
                         userData?.plan === 'basic' || (userData?.plan as string) === 'free' ? `${Math.max(0, 5 - (userData?.designsUsed || 0))} Left` :
                         'Basic'}
                      </span>
                      <span className="text-xs font-medium text-slate-700 group-hover:text-slate-900 transition-colors">{user.displayName}</span>
                    </div>
                    <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 group-hover:border-slate-300 transition-all">
                      {user.photoURL ? (
                        <img src={user.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full bg-slate-100 flex items-center justify-center text-slate-400">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  </Link>
                  <button
                    onClick={logout}
                    className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={login}
                  className="flex items-center gap-2 bg-slate-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-slate-800 transition-colors"
                >
                  <LogIn className="w-4 h-4" /> Login
                </button>
              )}
            </nav>

            <button
              className="md:hidden p-2 text-slate-600"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-white pt-20 md:hidden"
          >
            <nav className="flex flex-col items-center gap-8 p-8">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className="text-2xl font-serif font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-grow">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-beige-200 px-6 py-3 flex justify-between items-center z-50">
        {navItems.map((item) => (
          <Link
            key={item.name}
            to={item.path}
            className={cn(
              "flex flex-col items-center gap-1",
              location.pathname === item.path ? "text-slate-900" : "text-slate-400"
            )}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{item.name}</span>
          </Link>
        ))}
      </nav>

      <footer className="bg-beige-100 py-16 px-4 md:px-8 border-t border-beige-200">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                <Sparkles className="w-6 h-6 text-slate-800" />
              </div>
              <span className="text-2xl font-serif font-bold tracking-tight">DesignMySpace</span>
            </Link>
            <p className="text-slate-500 max-w-sm leading-relaxed">
              AI-powered interior design suggestion platform. Turn your space into a dream space with personalized, aesthetic designs.
            </p>
          </div>
          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-6">Quick Links</h4>
            <ul className="space-y-4 text-slate-600 text-sm font-medium">
              <li><Link to="/design" className="hover:text-[#c8a27a] transition-colors">Design Generator</Link></li>
              <li><Link to="/saved" className="hover:text-[#c8a27a] transition-colors">Saved Spaces</Link></li>
              <li><Link to="/pricing" className="hover:text-[#c8a27a] transition-colors">Pricing Plans</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-6">Support & Legal</h4>
            <ul className="space-y-4 text-slate-600 text-sm font-medium">
              <li><Link to="/support" className="hover:text-[#c8a27a] transition-colors">Support Center</Link></li>
              <li><Link to="/privacy" className="hover:text-[#c8a27a] transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-[#c8a27a] transition-colors">Terms of Service</Link></li>
              <li><Link to="/contact" className="hover:text-[#c8a27a] transition-colors">Contact Us</Link></li>
              <li><Link to="/developers" className="hover:text-[#c8a27a] transition-colors">Meet the Developers</Link></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-beige-200 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-[10px] font-bold uppercase tracking-widest">
          <span>© 2026 DesignMySpace. All rights reserved.</span>
          <div className="flex gap-8">
            <Link to="/support" className="hover:text-slate-600 transition-colors">Support</Link>
            <Link to="/privacy" className="hover:text-slate-600 transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-slate-600 transition-colors">Terms</Link>
            <Link to="/contact" className="hover:text-slate-600 transition-colors">Contact</Link>
            <Link to="/developers" className="hover:text-slate-600 transition-colors">Developers</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
